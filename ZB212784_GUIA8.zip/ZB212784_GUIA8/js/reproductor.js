document.addEventListener("DOMContentLoaded", function () {
    const musicPlayer = document.getElementById("musicPlayer");
    const songInfo = document.getElementById("songInfo");

    function cargarCancion() {
        musicPlayer.play();

        const songTitle = "Ferxxo 100";
        const songArtist = "Feid";

        songInfo.textContent = `${songTitle} - ${songArtist}`;
    }
        
    cargarCancion();
});
